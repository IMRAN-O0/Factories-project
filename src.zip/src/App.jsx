import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { create } from 'zustand';

// Import LoadingScreen
import LoadingScreen from './components/common/LoadingScreen';

// Import Components
import LoginSetup from './pages/auth/LoginSetup.jsx';
import Dashboard from './pages/core/Dashboard.jsx';
import LoginPage from './pages/core/LoginPage.jsx';
import UserManagement from './pages/auth/UserManagement.jsx';

// Production Components
import BatchProductionRecord from './pages/production/BatchProductionRecord.jsx';
import EquipmentCalibration from './pages/production/EquipmentCalibration.jsx';
import EquipmentMaintenance from './pages/production/EquipmentMaintenance.jsx';
import ProductionLineCleaning from './pages/production/ProductionLineCleaning.jsx';

// Inventory Components
import AddMaterial from './pages/inventory/AddMaterial.jsx';
import MaterialReceipt from './pages/inventory/MaterialReceipt.jsx';
import MaterialIssue from './pages/inventory/MaterialIssue.jsx';
import InventoryCount from './pages/inventory/InventoryCount.jsx';
import ViewMaterials from './pages/inventory/ViewMaterials.jsx';
import ExpiryReports from './pages/inventory/ExpiryReports.jsx';

// Quality Components
import RawMaterialsInspection from './pages/quality/RawMaterialsInspection.jsx';
import FinalProductInspection from './pages/quality/FinalProductInspection.jsx';
import NonConformanceRecord from './pages/quality/NonConformanceRecord.jsx';
import CorrectiveActionReport from './pages/quality/CorrectiveActionReport.jsx';
import COAReport from './pages/quality/COAReport.jsx';

// Safety Components
import IncidentReport from './pages/safety/IncidentReport.jsx';
import SafetyEquipmentInspection from './pages/safety/SafetyEquipmentInspection.jsx';
import TrainingRecord from './pages/safety/TrainingRecord.jsx';

// Sales Components
import Customers from './pages/sales/customers.jsx';
import Products from './pages/sales/products.jsx';
import Quotation from './pages/sales/quotation.jsx';
import Invoices from './pages/sales/invoices.jsx';

// Settings Components
import { SettingsPage } from './pages/settings';

// Global State Management
// Global State Management - Fix initial state values
const useAppStore = create((set, get) => ({
  // Authentication state - Fix undefined values
  user: null,
  isAuthenticated: false,
  
  // Tenant configuration - Provide proper defaults
  tenantConfig: {
    companyName: 'نظام إدارة المصانع المتكامل',
    logo: '',
    theme: 'default'
  },
  isConfigured: true,
  
  // Application settings - Fix undefined values
  currentModule: 'dashboard',
  sidebarOpen: true,
  
  // Actions
  login: (userData) => {
    set({ user: userData, isAuthenticated: true });
    localStorage.setItem('authUser', JSON.stringify(userData));
  },
  
  logout: () => {
    set({ user: null, isAuthenticated: false });
    localStorage.removeItem('authUser');
  },
  
  setTenantConfig: (config) => {
    const updatedConfig = { ...get().tenantConfig, ...config };
    set({ tenantConfig: updatedConfig, isConfigured: true });
    localStorage.setItem('tenantConfig', JSON.stringify(updatedConfig));
  },
  
  setCurrentModule: (module) => set({ currentModule: module }),
  
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  
  // Initialize app from localStorage - Fix error handling
  initializeApp: () => {
    try {
      // Check for existing user session
      const storedUser = localStorage.getItem('authUser');
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        if (userData && userData.id) {
          set({ user: userData, isAuthenticated: true });
        }
      }
      
      // Check for tenant configuration
      const storedConfig = localStorage.getItem('tenantConfig');
      if (storedConfig) {
        const configData = JSON.parse(storedConfig);
        if (configData) {
          set({ tenantConfig: { ...get().tenantConfig, ...configData }, isConfigured: true });
        }
      }
    } catch (error) {
      console.error('Error initializing app:', error);
      // Clear corrupted data
      localStorage.removeItem('authUser');
      localStorage.removeItem('tenantConfig');
      set({ 
        user: null, 
        isAuthenticated: false,
        tenantConfig: {
          companyName: 'نظام إدارة المصانع المتكامل',
          logo: '',
          theme: 'default'
        }
      });
    }
  }
}));

// Protected Route Component
const ProtectedRoute = ({ children, requiredRoles = [] }) => {
  const { user, isAuthenticated } = useAppStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  if (requiredRoles.length > 0 && !requiredRoles.includes(user?.role)) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-lg text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">غير مصرح</h2>
          <p className="text-gray-600 mb-4">ليس لديك صلاحية للوصول لهذه الصفحة</p>
          <button
            onClick={() => window.history.back()}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            العودة
          </button>
        </div>
      </div>
    );
  }
  
  return children;
};

// Setup Required Component
const SetupRequired = ({ children }) => {
  const { isConfigured } = useAppStore();
  
  if (!isConfigured) {
    return <LoginSetup />;
  }
  
  return children;
};

// Loading Component
const LoadingScreen = () => (
  <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
    <div className="text-center">
      <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
      <h2 className="text-xl font-semibold text-gray-700 mb-2">جاري التحميل...</h2>
      <p className="text-gray-500">نظام إدارة المصانع المتكامل</p>
    </div>
  </div>
);

import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';

// Layout Component
const MainLayout = ({ children }) => (
  <div className="flex h-screen bg-gray-100" dir="rtl">
    <Sidebar />
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header />
      <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200 p-6">
        {children}
      </main>
    </div>
  </div>
);

// Main App Component
const App = () => {
  const [isLoading, setIsLoading] = useState(true);
  const { initializeApp, isConfigured, isAuthenticated } = useAppStore();
  
  useEffect(() => {
    // Initialize the application
    initializeApp();
    
    // Simulate loading time for better UX
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, [initializeApp]);
  
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  return (
    <Router>
      <div className="min-h-screen bg-gray-50" dir="rtl">
        <Routes>
          {/* Setup Route - Always accessible if not configured */}
          {!isConfigured && (
            <Route path="/*" element={<LoginSetup />} />
          )}
          
          {/* Authentication Routes */}
          {isConfigured && (
            <>
              <Route 
                path="/login" 
                element={
                  isAuthenticated ? 
                  <Navigate to="/dashboard" replace /> : 
                  <LoginPage />
                } 
              />
              
              {/* Protected Routes */}
              <Route path="/dashboard" element={<ProtectedRoute><MainLayout><Dashboard /></MainLayout></ProtectedRoute>} />
              <Route path="/users" element={<ProtectedRoute requiredRoles={['admin']}><MainLayout><UserManagement /></MainLayout></ProtectedRoute>} />
              
              {/* Production Routes */}
              <Route path="/production/batch-record" element={<ProtectedRoute requiredRoles={['admin', 'production', 'supervisor']}><MainLayout><BatchProductionRecord /></MainLayout></ProtectedRoute>} />
              <Route path="/production/equipment-calibration" element={<ProtectedRoute requiredRoles={['admin', 'production', 'maintenance']}><MainLayout><EquipmentCalibration /></MainLayout></ProtectedRoute>} />
              <Route path="/production/equipment-maintenance" element={<ProtectedRoute requiredRoles={['admin', 'production', 'maintenance']}><MainLayout><EquipmentMaintenance /></MainLayout></ProtectedRoute>} />
              <Route path="/production/line-cleaning" element={<ProtectedRoute requiredRoles={['admin', 'production']}><MainLayout><ProductionLineCleaning /></MainLayout></ProtectedRoute>} />
              
              {/* Inventory Routes */}
              <Route path="/inventory/add" element={<ProtectedRoute requiredRoles={['admin', 'inventory']}><MainLayout><AddMaterial /></MainLayout></ProtectedRoute>} />
              <Route path="/inventory/receipt" element={<ProtectedRoute requiredRoles={['admin', 'inventory']}><MainLayout><MaterialReceipt /></MainLayout></ProtectedRoute>} />
              <Route path="/inventory/issue" element={<ProtectedRoute requiredRoles={['admin', 'inventory']}><MainLayout><MaterialIssue /></MainLayout></ProtectedRoute>} />
              <Route path="/inventory/count" element={<ProtectedRoute requiredRoles={['admin', 'inventory']}><MainLayout><InventoryCount /></MainLayout></ProtectedRoute>} />
              <Route path="/inventory/view" element={<ProtectedRoute requiredRoles={['admin', 'inventory', 'viewer']}><MainLayout><ViewMaterials /></MainLayout></ProtectedRoute>} />
              <Route path="/inventory/expiry" element={<ProtectedRoute requiredRoles={['admin', 'inventory', 'quality']}><MainLayout><ExpiryReports /></MainLayout></ProtectedRoute>} />
              
              {/* Quality Routes */}
              <Route path="/quality/raw-materials" element={<ProtectedRoute requiredRoles={['admin', 'quality']}><MainLayout><RawMaterialsInspection /></MainLayout></ProtectedRoute>} />
              <Route path="/quality/final-product" element={<ProtectedRoute requiredRoles={['admin', 'quality']}><MainLayout><FinalProductInspection /></MainLayout></ProtectedRoute>} />
              <Route path="/quality/non-conformance" element={<ProtectedRoute requiredRoles={['admin', 'quality']}><MainLayout><NonConformanceRecord /></MainLayout></ProtectedRoute>} />
              <Route path="/quality/corrective-action" element={<ProtectedRoute requiredRoles={['admin', 'quality']}><MainLayout><CorrectiveActionReport /></MainLayout></ProtectedRoute>} />
              <Route path="/quality/coa" element={<ProtectedRoute requiredRoles={['admin', 'quality']}><MainLayout><COAReport /></MainLayout></ProtectedRoute>} />
              
              {/* Safety Routes */}
              <Route path="/safety/incident" element={<ProtectedRoute requiredRoles={['admin', 'safety', 'supervisor']}><MainLayout><IncidentReport /></MainLayout></ProtectedRoute>} />
              <Route path="/safety/equipment" element={<ProtectedRoute requiredRoles={['admin', 'safety']}><MainLayout><SafetyEquipmentInspection /></MainLayout></ProtectedRoute>} />
              <Route path="/safety/training" element={<ProtectedRoute requiredRoles={['admin', 'hr', 'supervisor']}><MainLayout><TrainingRecord /></MainLayout></ProtectedRoute>} />
              
              {/* Sales Routes */}
              <Route path="/sales/customers" element={<ProtectedRoute requiredRoles={['admin', 'sales']}><MainLayout><Customers /></MainLayout></ProtectedRoute>} />
              <Route path="/sales/products" element={<ProtectedRoute requiredRoles={['admin', 'sales', 'production']}><MainLayout><Products /></MainLayout></ProtectedRoute>} />
              <Route path="/sales/quotation" element={<ProtectedRoute requiredRoles={['admin', 'sales']}><MainLayout><Quotation /></MainLayout></ProtectedRoute>} />
              <Route path="/sales/invoices" element={<ProtectedRoute requiredRoles={['admin', 'sales']}><MainLayout><Invoices /></MainLayout></ProtectedRoute>} />
              
              {/* Settings Routes */}
              <Route path="/settings" element={<ProtectedRoute requiredRoles={['admin']}><MainLayout><SettingsPage /></MainLayout></ProtectedRoute>} />
              
              {/* Default redirect */}
              <Route path="/" element={
                <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
              } />
              
              {/* 404 Route */}
              <Route path="*" element={
                <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                  <div className="text-center">
                    <h1 className="text-6xl font-bold text-gray-400 mb-4">404</h1>
                    <h2 className="text-2xl font-semibold text-gray-600 mb-4">الصفحة غير موجودة</h2>
                    <p className="text-gray-500 mb-8">الصفحة التي تبحث عنها غير متاحة</p>
                    <button
                      onClick={() => window.history.back()}
                      className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      العودة للخلف
                    </button>
                  </div>
                </div>
              } />
            </>
          )}
        </Routes>
      </div>
    </Router>
  );
};

export default App;

// Export the store for use in other components
export { useAppStore };
