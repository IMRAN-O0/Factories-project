import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Users, Package, ShoppingCart, FileText, 
  Truck, BarChart3, Factory, Settings, Shield, AlertTriangle, CheckCircle
} from 'lucide-react';
import useAuth from '../../hooks/useAuth';

const navigationLinks = [
  {
    group: 'الرئيسية',
    links: [
      { path: '/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
      { path: '/users', label: 'إدارة المستخدمين', icon: Users, role: 'admin' },
    ]
  },
  {
    group: 'المبيعات',
    links: [
      { path: '/sales/customers', label: 'العملاء', icon: Users },
      { path: '/sales/products', label: 'المنتجات', icon: Package },
      { path: '/sales/quotation', label: 'عروض الأسعار', icon: FileText },
      { path: '/sales/invoices', label: 'الفواتير', icon: FileText },
    ]
  },
  {
    group: 'المستودعات',
    links: [
      { path: '/inventory/view', label: 'عرض المواد', icon: Package },
      { path: '/inventory/add', label: 'إضافة مواد', icon: Package },
      { path: '/inventory/receipt', label: 'استلام مواد', icon: Truck },
      { path: '/inventory/issue', label: 'صرف مواد', icon: Package },
      { path: '/inventory/count', label: 'جرد المخزون', icon: BarChart3 },
      { path: '/inventory/expiry', label: 'تقارير الصلاحية', icon: AlertTriangle },
    ]
  },
  {
    group: 'الإنتاج',
    links: [
      { path: '/production/batch-record', label: 'سجل الإنتاج', icon: FileText },
      { path: '/production/equipment-maintenance', label: 'صيانة المعدات', icon: Settings },
      { path: '/production/equipment-calibration', label: 'معايرة المعدات', icon: Settings },
      { path: '/production/line-cleaning', label: 'تنظيف الخط', icon: Settings },
    ]
  },
  {
    group: 'الجودة',
    links: [
      { path: '/quality/raw-materials', label: 'فحص المواد الخام', icon: FileText },
      { path: '/quality/final-product', label: 'فحص المنتج النهائي', icon: CheckCircle },
      { path: '/quality/non-conformance', label: 'عدم المطابقة', icon: AlertTriangle },
      { path: '/quality/coa', label: 'شهادة التحليل', icon: FileText },
    ]
  },
  {
    group: 'السلامة',
    links: [
      { path: '/safety/incident', label: 'تقرير حادث', icon: AlertTriangle },
      { path: '/safety/equipment', label: 'فحص معدات السلامة', icon: Shield },
      { path: '/safety/training', label: 'سجل التدريب', icon: FileText },
    ]
  },
  {
    group: 'النظام',
    links: [
      { path: '/settings', label: 'الإعدادات', icon: Settings, role: 'admin' },
    ]
  },
];

const Sidebar = () => {
  const { user } = useAuth();
  
  // فلترة الروابط بناءً على دور المستخدم
  const getFilteredLinks = (links) => {
    return links.filter(link => {
      if (!link.role) return true; // إذا لم يكن هناك دور مطلوب، اعرض الرابط
      if (!user || !user.roles) return false; // إذا لم يكن هناك مستخدم أو أدوار، لا تعرض الرابط
      return user.roles.includes(link.role); // تحقق من وجود الدور المطلوب
    });
  };

  return (
    <aside className="w-64 bg-white shadow-md h-screen p-4" dir="rtl">
      <div className="mb-8 text-center">
        <h2 className="text-2xl font-bold text-blue-600">QASD</h2>
        <p className="text-xs text-gray-500">نظام إدارة المصانع</p>
      </div>
      <nav>
        <ul>
          {navigationLinks.map((group, index) => {
            const filteredLinks = getFilteredLinks(group.links);
            
            // إذا لم تكن هناك روابط مرئية في المجموعة، لا تعرض المجموعة
            if (filteredLinks.length === 0) return null;
            
            return (
              <li key={index} className="mb-6">
                <h3 className="text-gray-500 text-sm font-semibold mb-2 px-2">{group.group}</h3>
                <ul>
                  {filteredLinks.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <NavLink
                        to={link.path}
                        className={({ isActive }) =>
                          `flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                            isActive
                              ? 'bg-blue-100 text-blue-600'
                              : 'text-gray-700 hover:bg-gray-100'
                          }`
                        }
                      >
                        <link.icon className="h-5 w-5" />
                        {link.label}
                      </NavLink>
                    </li>
                  ))}
                </ul>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
